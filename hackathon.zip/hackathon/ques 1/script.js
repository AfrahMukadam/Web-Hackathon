angular.module("toDoList", [])

.controller("toDoListCtrl", ['$scope',
    function($scope) {
        //A model holding tasks
        $scope.taskList = [

        ];
        let id = 0;
        //Function for adding task to the task list
        $scope.addTask = function(task) {
            //I'm pushing a new task to the task list
            $scope.taskList.push({
                id: id,
                done: false,
                taskname: task,
                taskstatus: "NO",
            });
            id++;
        };

    }
]);